<?php
// Heading
$_['heading_title'] = 'عدد الباعة';

// Text
$_['text_view'] = 'المزيد ...';
