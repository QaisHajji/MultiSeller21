<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title'] = 'الاعدادات';


        $_['tab_multiseller_setting'] = 'MultiSeller اعدادات';
$_['tab_multisellergeneral'] = 'عام';
$_['tab_multisellerproductsetting'] = 'اعدادات المنتجات';
$_['tab_multisellerordersetting'] = 'اعدادات الطلبيات';
$_['tab_multisellerdownloadsetting'] = 'اعدادات التنزيلات';

$_['text_sellerdownloadstatus'] = 'السماح للباعة برفع ملفات للتنزيل';

$_['text_seller_agree'] = 'شروط انشاء حساب بائع';
$_['text_sellerreview'] = 'حالة تقييم الباعة';
$_['text_sellerreviewguest'] = 'السماح للزوار بتقييم الباعة؟';

$_['text_sellerorderstatus'] = 'السماح للباعة بتغيير حالة الطلب';
$_['text_sellerordernotifyhistory'] = 'السماح للباعة بتنيه العميل واضافة تعليقات';
$_['text_sellerordersettlement'] = 'السماح للباعة بمخالصة الطلبات';

$_['text_sellerimageupload'] = 'السماح للبائع برفع صورة شخصية';
$_['text_sellerprofileimage'] = 'عرص الصورة الشخصية في ملف البائع';
$_['text_sellerproductname'] = 'عرض اسم البائع في صفحة المنتج';
$_['text_sellerproductimage'] = 'عرض صورة البائع في صفحة المنتج';
$_['text_sellerproductdateofcreat'] = 'عرض تاريخ انضمام البائع في صفحة المنتج';
$_['text_sellerproductcount'] = 'عرض عدد منتجات البائع في صفحة المنتج';
$_['text_sellerproductbadge'] = 'عرض أوسمة البائع في صفحة المنتج';
$_['text_sellerproductrating'] = 'عرض تقييم البائع في صفحة المنتج';

$_['text_sellerwebsite'] = 'عرض موقع البائع في صفحة المنتج';
$_['text_sellerfacebook'] = 'عرض حساب فيسبوك البائع في صفحة المنتج';
$_['text_sellertwitter'] = 'عرض حساب تويتر البائع في صفحة المنتج';
$_['text_sellergoogleplus'] = 'عرض حساب غوغول بلس البائع في صفحة المنتج';
$_['text_sellerinstagram'] = 'عرض حساب انستاغرام البائع في صفحة المنتج';
$_['text_seller_add_product_alert'] = 'تنبيه مدير المتجر عند اضافة منتج جديد';
      
